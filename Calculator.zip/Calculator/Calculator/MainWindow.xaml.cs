﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Net;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.IO;
using System.Xml;
using System.Data;
using System.Xml.Serialization;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string num = "0";
        double firstNum = 0, secondNum = 0;
        bool isNum2 = false, _operatorChanged = false, isEqualClicked = false;
        string _operator = "+";
        int histCount = 0;
        List<string> memory = new List<string>();
        public ObservableCollection<string> UsersList = new ObservableCollection<string>();
        public MainWindow()
        {
            InitializeComponent();
            txtValue_Copy.Focus();

        }
        private void btnNum_Click(object sender, RoutedEventArgs e)
        {
            var value = (sender as Button).Content.ToString();
            if ((value == "." && num.Contains(".")) || txtValue.Text.Length > 15)
            {
                //do nothing
            }
            else
            {
                if (_operatorChanged == true)
                {
                    num = "0";
                }
                _operatorChanged = false;
                if (value == "." && num == "0")
                {
                    value = "0.";
                }
                num = num == "0" ? value : num + value;
                txtValue.Text = string.Format("{0:#,##0.###############}", num);

                if (isNum2)
                {
                    secondNum = double.Parse(num);
                }
                else
                {
                    firstNum = double.Parse(num);
                }
            }
        }
        private void changeOperation()
        {
            _operatorChanged = true;
            ComboBoxItem typeItem = (ComboBoxItem)cmbOperation.SelectedItem;
            _operator = typeItem.Content.ToString();
            if (isNum2 == true)
            {
                btnEquals.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
            else
            {
                histCount++;
                var oppHist = (_operator == "+" ? "Add" : (_operator == "-" ? "Subtract" : (_operator == "×" ? "Multiply" : (_operator == "÷" ? "Divide" : ""))));
                listView.Items.Add(new History(histCount, oppHist, txtValue.Text));
            }

            txtCalcValue.Text = string.Format("{0:#,##0.###############}", double.Parse(num)) + _operator;
            isNum2 = true;
            secondNum = firstNum;


        }
        private void cmbOperation_DropDownClosed(object sender, EventArgs e)
        {
            changeOperation();
        }
        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            txtValue.Text = txtValue.Text.Substring(0, txtValue.Text.Length - 1);
            txtValue.Text = txtValue.Text == "" ? "0" : txtValue.Text;
            num = txtValue.Text;
            if (isEqualClicked)
            {
                secondNum = double.Parse(num);
            }
        }

        private void btnplusminus_Click(object sender, RoutedEventArgs e)
        {
            if (double.Parse(txtValue.Text) < 0)
            {
                txtValue.Text = txtValue.Text.Trim('-');
            }
            else
            {
                if (double.Parse(txtValue.Text) != 0)
                {
                    txtValue.Text = "-" + txtValue.Text;
                }
            }

            num = txtValue.Text;
            if (isNum2)
            {
                secondNum = double.Parse(num);
            }
            else
            {
                firstNum = double.Parse(num);
            }
        }

        private void btnC_Click(object sender, RoutedEventArgs e)
        {
            isEqualClicked = false;
            num = "0";
            txtCalcValue.Clear();
            firstNum = 0;
            secondNum = 0;
            txtValue.Text = "0";
            histCount++;
            listView.Items.Add(new History(histCount, "Clear", txtValue.Text));
        }

        private void MenuItemClear_Click(object sender, RoutedEventArgs e)
        {
            btnC.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }

        private void MenuItemExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MenuItemCopy_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(txtValue.Text);
        }

        private void MenuItemPaste_Click(object sender, RoutedEventArgs e)
        {
            txtValue.Text = Regex.Match(Clipboard.GetText(), @"\d+").Value;
            num = txtValue.Text;
        }

        private void btnMP_Click(object sender, RoutedEventArgs e)
        {
            if (memory.Count()==0)
            {
                memory.Add(string.Format("{0:#,##0.###############}", double.Parse(txtValue.Text)));
            }
            else
            {
                memory[memory.Count-1] = string.Format("{0:#,##0.###############}", double.Parse(memory[memory.Count-1]) + double.Parse(txtValue.Text));
            }
            num = "0";
            listBox.Items.Clear();
            for (int i = memory.Count-1; i >= 0 ; i--)
            {
                listBox.Items.Add(memory[i]);
            }
            btnMC.IsEnabled = true;
            btnMR.IsEnabled = true;
        }

        private void btnMM_Click(object sender, RoutedEventArgs e)
        {
            if (memory.Count() == 0)
            {
                memory.Add("-"+string.Format("{0:#,##0.###############}", double.Parse(txtValue.Text)));
            }
            else
            {
                memory[memory.Count-1] = string.Format("{0:#,##0.###############}", double.Parse(memory[memory.Count - 1]) - double.Parse(txtValue.Text));
            }
            num = "0";
            listBox.Items.Clear();
            for (int i = memory.Count - 1; i >= 0; i--)
            {
                listBox.Items.Add(memory[i]);
            }
            btnMC.IsEnabled = true;
            btnMR.IsEnabled = true;
        }

        private void btnMR_Click(object sender, RoutedEventArgs e)
        {
            txtValue.Text = memory[memory.Count - 1];
            num = memory[memory.Count - 1];
        }

        private void btnMC_Click(object sender, RoutedEventArgs e)
        {
            memory.Clear();
            num = "0";
            btnMC.IsEnabled = false;
            btnMR.IsEnabled = false;
            listBox.Items.Clear();
        }

        private void btnMS_Click(object sender, RoutedEventArgs e)
        {
            memory.Add(string.Format("{0:#,##0.###############}", double.Parse(txtValue.Text)));
            listBox.Items.Clear();
            for (int i = memory.Count - 1; i >= 0; i--)
            {
                listBox.Items.Add(memory[i]);
            }
            num = "0";
            btnMC.IsEnabled = true;
            btnMR.IsEnabled = true;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            FileStream fileStream;
            StreamWriter streamWriter;
            XmlTextWriter xmlTextWriter;

            try
            {
                // overwrite even if it already exists
                fileStream = new FileStream("History", FileMode.Create, FileAccess.Write, FileShare.None);

                streamWriter = new StreamWriter(fileStream);
                xmlTextWriter = new XmlTextWriter(streamWriter);
                xmlTextWriter.Formatting = Formatting.Indented;
                xmlTextWriter.WriteStartDocument();
                xmlTextWriter.WriteStartElement("Items");

                foreach (var item in listView.Items)
                {
                    int currentSubItem1 = ((Calculator.History)item).HistID;
                    String currentSubItem2 = ((Calculator.History)item).Action;
                    String currentSubItem3 = ((Calculator.History)item).Value;

                    xmlTextWriter.WriteStartElement("Item");
                    xmlTextWriter.WriteAttributeString("subitem1", currentSubItem1.ToString());
                    xmlTextWriter.WriteAttributeString("subitem2", currentSubItem2.ToString());
                    xmlTextWriter.WriteAttributeString("subitem3", currentSubItem3.ToString());
                    xmlTextWriter.WriteEndElement();
                }

                xmlTextWriter.WriteEndDocument();
                xmlTextWriter.Flush();
                xmlTextWriter.Close();
            }
            catch (IOException ex)
            {
                

            }

        }

        private void btnCE_Click(object sender, RoutedEventArgs e)
        {
            txtValue.Text = "0";
            num = "0";
            histCount++;
            listView.Items.Add(new History(histCount, "Clear Entry", txtValue.Text));
        }
        private void OnKeyDownHandler(object sender, System.Windows.Input.KeyEventArgs e)
        {
            string[] nums = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "*", "/", "+", "=", "." };
            if ((Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift)) && Keyboard.IsKeyDown(Key.OemPlus))
            {
                cmbOperation.SelectedIndex = 0;
                changeOperation();
            }
            else if ((Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift)) && Keyboard.IsKeyDown(Key.D8))
            {
                cmbOperation.SelectedIndex = 2;
                changeOperation();
            }
            else if (Keyboard.IsKeyDown(Key.Back))
            {
                btnRemove.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
            else if (Keyboard.IsKeyDown(Key.Escape))
            {
                btnC.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }

            else if ((Keyboard.IsKeyDown(Key.LeftCtrl)|| Keyboard.IsKeyDown(Key.RightCtrl))&& Keyboard.IsKeyDown(Key.V))
            {
                txtValue.Text = Regex.Match(Clipboard.GetText(), @"\d+").Value;
                num = txtValue.Text;
            }
            else if (!nums.Contains(e.Key.ToString()))
            {
                if (e.Key.ToString()=="D1")
                {
                    btn1.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "D2")
                {
                    btn2.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "D3")
                {
                    btn3.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "D4")
                {
                    btn4.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "D5")
                {
                    btn5.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "D6")
                {
                    btn6.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "D7")
                {
                    btn7.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "D9")
                {
                    btn9.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "D0")
                {
                    btn0.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                else if (e.Key.ToString() == "OemPlus")
                {
                    btnEquals.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }

                else if (e.Key.ToString() == "OemMinus")
                {
                    cmbOperation.SelectedIndex = 1;
                    changeOperation();
                }
                else if (e.Key.ToString() == "OemQuestion")
                {
                    cmbOperation.SelectedIndex = 3;
                    changeOperation();
                }
                else if (e.Key.ToString() == "D8")
                {
                    btn8.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
            }
        }

        private void btnEquals_Click(object sender, RoutedEventArgs e)
        {
            isEqualClicked = true;
            if (_operator=="+")
            {
                txtValue.Text = string.Format("{0:#,##0.###############}", firstNum + secondNum);
            }
            else if (_operator=="-")
            {
                txtValue.Text = string.Format("{0:#,##0.###############}", firstNum - secondNum);
            }
            else if (_operator == "÷")
            {
                txtValue.Text = string.Format("{0:#,##0.###############}", firstNum / secondNum);
            }
            else if (_operator == "×")
            {
                txtValue.Text = string.Format("{0:#,##0.###############}", firstNum * secondNum);
            }
            if (isNum2 ==false)
            {
                if (num=="0")
                {
                    txtCalcValue.Text = string.Format("{0:#,##0.###############}", firstNum) + "=";
                }
                else
                {
                    txtCalcValue.Text = string.Format("{0:#,##0.###############}", firstNum) + cmbOperation.Text + string.Format("{0:#,##0.###############}", secondNum) + "=";
                }
            }
            else
            {
                txtCalcValue.Text = string.Format("{0:#,##0.###############}", firstNum) + cmbOperation.Text + string.Format("{0:#,##0.###############}", secondNum ) + "=";
            }
            histCount++;
            string action ="";
            if (_operatorChanged == true)
            {
                ComboBoxItem typeItem = (ComboBoxItem)cmbOperation.SelectedItem;
                _operator = typeItem.Content.ToString();
                var oppHist = (_operator == "+" ? "Add" : (_operator == "-" ? "Subtract" : (_operator == "×" ? "Multiply" : (_operator == "÷" ? "Divide" : ""))));
                action = oppHist;
            }
            else
            {
                action = "Equal";
            }
            listView.Items.Add(new History(histCount, action, txtValue.Text));
            firstNum = double.Parse(txtValue.Text);
            num =  txtValue.Text;
            isNum2 = false;
            _operatorChanged = true;

        }


     
    }
    class History
    {
        int ID;
        string action;
        string val;

        public History(int id, string action, string val)
        {
            this.HistID = id;
            this.action = action;
            this.val = val;
        }
        public int HistID
        {
            get { return ID; }
            set { ID = value; }
        }
        public string Action
        {
            get { return action; }
            set { action = value; }
        }
        public string Value
        {
            get { return val; }
            set { val = value; }
        }
    }
}
